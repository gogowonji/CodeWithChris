//Lesson 6 with CodeWithChris
var a = 20 + 5
var b = 20 - 5
var c = 20 * 5
var d = 20 / 5
var e = 20 % 2
var f = (a*b) + (c/d)

f = f + 1 //f += 1
f -= 1
f *= 2
f /= 4

import Foundation
var g = abs(-1) //절대값
var h = ceil(1.8) //올림
var i = floor(1.4) //내림
var j = sqrt(36) //루트
var k = pow(2,4) //제곱

let people:Double = 4
let subtotal:Double = 128
let tax = 0.13
var split:Double = 0

split = 128 * (1 + 0.13) / 4
print(split)



//Lesson 7
import UIKit
func myFunc(a:Int, b:Int = 0) -> Int {
    return a+b
}
myFunc(a: 2, b: 3)
myFunc(a: 10)
func myFunc(_ a:Int, _ b:Int = 0) -> Int {

    return a+b
}
myFunc(10, 3)


//ch 1
func goodMorning(){
    print("Good Morning")
}
goodMorning()

//ch 2
func printTotlaWithTax(subtotal:Double){
    print(subtotal*1.13)
}
printTotlaWithTax(subtotal: 100)

//ch 3
func getTotalWithTax(subtotal : Double)->Double{
    return subtotal * 1.13
}
print(getTotalWithTax(subtotal: 200))

//ch 4
func calculateTotalWithTax(subtotal:Double, tax:Double) -> Double{
    return subtotal * (1 + tax)
}
print(calculateTotalWithTax(subtotal: 100, tax: 0.13))



//Lesson 8
struct ChatView{
    //Propertices (Variables and Constants)
    var message : String = "" //xcode determine ok
    var messageWithPrefix:String{
        let prefix = "Chris says: "
        return prefix + message
    }

    //View code for this screen (UI)


    //Methods (Functions in Structure)
    func sendChat() {
        // Code to sent the char message
        print(messageWithPrefix)
    }

    func deleteChat() {

        print(messageWithPrefix)
    }
}


struct Car {
    private var make:String = "Toyota"
    private var model:String = "Camry"
    private var year:String = "1999"
    private var details:String{
        year + " " + make + " " + model
    }
    func getDetails() -> String{
        return details
    }
}

//Lesson 9
struct DatabaseManager {
    private var serverName = "Server 1"
    
    func saveData(data:String) -> Bool {
        
        //This code saves the data and returns a boolean result
        return true
    }
}
struct ChatView1 {
    var message = "Hello"
    
    func sendChat(){
        //Save the chat message
        var db = DatabaseManager()
        //Check the suceessful boolean value, if unsuccessful, show alert to user
        let successful = db.saveData(data : message)
        
    }
}

//ch1
/*Declare a struct called TaxCalculator
 
 Declare a property inside called tax and set it to a decimal value representing the amount of sales tax where you live

 Declare a method inside called totalWithTax that accepts a Double as an input parameter and returns a Double value.

 Inside that method, write the code to return a Double value representing the input number with tax included*/
struct TaxCalulator{
    var tax : Double = 0.03
    func totalWithTax(_ subTotal:Double) -> Double {
        return subTotal * (1+tax)
    }
}

//ch2
/* Declare a struct called BillSplitter
 
 Declare a method inside called splitBy that:

 has an input parameter of type Double representing a subtotal
 has an input parameter of type Int representing the number of people
 returns a Double value
 Inside that method, use an instance of TaxCalculator (from challenge 1 above) to calculate the total with tax and then split the bill by the number of people passed into the method.

 Return the amount that each person has to pay.

*/
struct BillSplitter{
    func splitBy(subtotal:Double, people : Double) -> Double{
        let taxCal = TaxCalulator()
        let totalWithTax =  taxCal.totalWithTax(subtotal)
        return totalWithTax / people
        //why do I see an error value of type Int? <people>
    }
}

//ch3
/* Create an instance of BillSplitter
 
 Use the instance to print out the amount that each person pays (Assuming 5 people with a bill of $120)*/

let inBill = BillSplitter()

print(inBill.splitBy(subtotal: 200, people: 5))


