////Lesson 6 with CodeWithChris
//var a = 20 + 5
//var b = 20 - 5
//var c = 20 * 5
//var d = 20 / 5
//var e = 20 % 2
//var f = (a*b) + (c/d)
//
//f = f + 1 //f += 1
//f -= 1
//f *= 2
//f /= 4
//
//import Foundation
//var g = abs(-1) //절대값
//var h = ceil(1.8) //올림
//var i = floor(1.4) //내림
//var j = sqrt(36) //루트
//var k = pow(2,4) //제곱
//
//let people:Double = 4
//let subtotal:Double = 128
//let tax = 0.13
//var split:Double = 0
//
//split = 128 * (1 + 0.13) / 4
//print(split)
//
//
//
////Lesson 7
//import UIKit
//func myFunc(a:Int, b:Int = 0) -> Int {
//    return a+b
//}
//myFunc(a: 2, b: 3)
//myFunc(a: 10)
//func myFunc(_ a:Int, _ b:Int = 0) -> Int {
//
//    return a+b
//}
//myFunc(10, 3)
//
//
////ch 1
//func goodMorning(){
//    print("Good Morning")
//}
//goodMorning()
//
////ch 2
//func printTotlaWithTax(subtotal:Double){
//    print(subtotal*1.13)
//}
//printTotlaWithTax(subtotal: 100)
//
////ch 3
//func getTotalWithTax(subtotal : Double)->Double{
//    return subtotal * 1.13
//}
//print(getTotalWithTax(subtotal: 200))
//
////ch 4
//func calculateTotalWithTax(subtotal:Double, tax:Double) -> Double{
//    return subtotal * (1 + tax)
//}
//print(calculateTotalWithTax(subtotal: 100, tax: 0.13))
//
//

//Lesson 8
struct ChatView{
    //Propertices (Variables and Constants)
    var message : String = "" //xcode determine ok
    var messageWithPrefix:String{
        let prefix = "Chris says: "
        return prefix + message
    }
    
    //View code for this screen (UI)
    
    
    //Methods (Functions in Structure)
    func sendChat() {
        // Code to sent the char message
        print(messageWithPrefix)
    }
    
    func deleteChat() {
    
        print(messageWithPrefix)
    }
}
